*PADS-LIBRARY-PART-TYPES-V9*

TPS2115ADRBT SON65P300X300X100-9N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.07.05.17.55.22
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS2115ADRBT
"Mouser Part Number" 595-TPS2115ADRBT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS2115ADRBT?qs=g%2FrhRe7LVpRzfUPvVko3fA%3D%3D
"Arrow Part Number" TPS2115ADRBT
"Arrow Price/Stock" https://www.arrow.com/en/products/tps2115adrbt/texas-instruments.html?utm_currency=USD&region=nac
"Description" Autoswitching Power Mux
"Datasheet Link" http://www.ti.com/lit/gpn/TPS2115A
"Geometry.Height" 1mm
GATE 1 9 0
TPS2115ADRBT
1 0 U STAT
2 0 U D0
3 0 U D1
4 0 U ILIM
9 0 U GND_2
8 0 U IN1
7 0 U OUT
6 0 U IN2
5 0 U GND_1

*END*
*REMARK* SamacSys ECAD Model
334160/1718724/2.50/9/3/Integrated Circuit
