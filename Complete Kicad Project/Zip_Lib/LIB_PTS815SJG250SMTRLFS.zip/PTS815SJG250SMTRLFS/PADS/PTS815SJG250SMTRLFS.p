*PADS-LIBRARY-PART-TYPES-V9*

PTS815SJG250SMTRLFS PTS815SJG250SMTRLFS I SWI 9 1 0 0 0
TIMESTAMP 2026.07.05.20.32.15
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" PTS815SJG250SMTRLFS
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" PTS815SJG250SMTRLFS
"Arrow Price/Stock" https://www.arrow.com/en/products/pts815-sjg-250-smtr-lfs/ck?region=nac
"Description" Switch Tactile N.O. SPST Button J-Bend 0.05A 12VDC 3.92N SMD T/R
"Datasheet Link" https://www.ckswitches.com/media/2728/pts815.pdf
"Geometry.Height" 2.7mm
GATE 1 4 0
PTS815SJG250SMTRLFS
1 0 U COM_1
2 0 U COM_2
3 0 U NO_1
4 0 U NO_2

*END*
*REMARK* SamacSys ECAD Model
3259512/1718724/2.50/4/2/Switch
