*PADS-LIBRARY-PART-TYPES-V9*

TLT9251VLEXUMA1 SON65P300X300X110-9N I ANA 9 1 0 0 0
TIMESTAMP 2026.07.05.18.59.40
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" TLT9251VLEXUMA1
"Mouser Part Number" 726-TLT9251VLEXUMA1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/TLT9251VLEXUMA1?qs=W%2FMpXkg%252BdQ5zGtp9sfvtfA%3D%3D
"Arrow Part Number" TLT9251VLEXUMA1
"Arrow Price/Stock" https://www.arrow.com/en/products/tlt9251vlexuma1/infineon-technologies-ag?region=nac
"Description" CAN Interface IC
"Datasheet Link" https://www.infineon.com/dgdl/Infineon-TLT9251VLE-DataSheet-v01_00-EN.pdf?fileId=5546d4626e8d4b8f016ea702cfff08e8
"Geometry.Height" 1.1mm
GATE 1 9 0
TLT9251VLEXUMA1
1 0 U TXD
2 0 U GND
3 0 U VCC
4 0 U RXD
9 0 U EP
8 0 U STB
7 0 U CANH
6 0 U CANL
5 0 U VIO

*END*
*REMARK* SamacSys ECAD Model
13003097/1718724/2.50/9/3/Integrated Circuit
