*PADS-LIBRARY-PART-TYPES-V9*

TPS7A0233DBVR SOT95P280X145-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.02.27.04.16.04
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS7A0233DBVR
"Mouser Part Number" 595-TPS7A0233DBVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS7A0233DBVR?qs=QNEnbhJQKvZidySW4FDctA%3D%3D
"Arrow Part Number" TPS7A0233DBVR
"Arrow Price/Stock" https://www.arrow.com/en/products/tps7a0233dbvr/texas-instruments?utm_currency=USD&region=nac
"Description" LDO Voltage Regulators 200mA nanopower-IQ (25 nA) low-dropout
"Datasheet Link" https://www.ti.com/lit/gpn/tps7a02
"Geometry.Height" 1.45mm
GATE 1 5 0
TPS7A0233DBVR
1 0 U IN
2 0 U GND
3 0 U EN
4 0 U NC
5 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
15929613/1718724/2.50/5/3/Integrated Circuit
