*PADS-LIBRARY-PART-TYPES-V9*

MMC5983MA MMC5983MA I ANA 9 1 0 0 0
TIMESTAMP 2026.02.27.03.55.05
"Manufacturer_Name" MEMSIC
"Manufacturer_Part_Number" MMC5983MA
"Mouser Part Number" 438-MMC5983MA
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/MEMSIC/MMC5983MA?qs=B6kkDfuK7%2FD5qasHMdEt2g%3D%3D
"Arrow Part Number" MMC5983MA
"Arrow Price/Stock" https://www.arrow.com/en/products/mmc5983ma/memsic?utm_currency=USD&region=nac
"Description" 3-AXIS MAGNETIC SENSOR
"Datasheet Link" https://www.mouser.com/datasheet/2/821/Memsic_09102019_MMC5983MA_Datasheet_Rev_A-1635338.pdf
"Geometry.Height" 1mm
GATE 1 16 0
MMC5983MA
1 0 U SCL/SPI_SCK
2 0 U VDD
3 0 U NC_1
4 0 U SPI_CS
5 0 U SPI_SDO
6 0 U NC_2
7 0 U NC_3
8 0 U NC_4
9 0 U GND_1
10 0 U CAP
11 0 U GND_2
12 0 U NC_5
13 0 U VDDIO
14 0 U NC_6
15 0 U INT
16 0 U SDA/SPI_SDI

*END*
*REMARK* SamacSys ECAD Model
4853130/1718724/2.50/16/4/Integrated Circuit
